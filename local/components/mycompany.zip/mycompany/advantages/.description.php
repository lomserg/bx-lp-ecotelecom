<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = [
    "NAME" => "Преимущества",
    "DESCRIPTION" => "Выводит список преимуществ компании",
    "PATH" => [
        "ID" => "mycompany",
        "NAME" => "Мои компоненты"
    ],
];