<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME" => "FAQ: Часто задаваемые вопросы",
    "DESCRIPTION" => "Выводит список вопросов и ответов из инфоблока",
    "ICON" => "/images/icon.gif",
    "PATH" => [
        "ID" => "mycompany",
        "NAME" => "Мои компоненты"
    ]
];