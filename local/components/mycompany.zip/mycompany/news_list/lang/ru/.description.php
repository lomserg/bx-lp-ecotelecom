<?
$MESS ['T_IBLOCK_DESC_LINE'] = "Лента";
$MESS ['T_IBLOCK_DESC_LINE_DESC'] = "Список статей и новостей с датой и заголовком";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Статьи и новости";
?>