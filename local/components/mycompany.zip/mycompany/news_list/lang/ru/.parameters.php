<?
$MESS ['IBLOCK_DETAIL_URL'] = "URL, ведущий на страницу с содержимым элемента раздела";
$MESS ['T_IBLOCK_DESC_ASC'] = "По возрастанию";
$MESS ['T_IBLOCK_DESC_DESC'] = "По убыванию";
$MESS ['T_IBLOCK_DESC_FID'] = "ID";
$MESS ['T_IBLOCK_DESC_FNAME'] = "Название";
$MESS ['T_IBLOCK_DESC_FACT'] = "Дата начала активности";
$MESS ['T_IBLOCK_DESC_FSORT'] = "Сортировка";
$MESS ['T_IBLOCK_DESC_FTSAMP'] = "Дата последнего изменения";
$MESS ['T_IBLOCK_DESC_IBORD1'] = "Поле для первой сортировки новостей";
$MESS ['T_IBLOCK_DESC_IBBY1'] = "Направление для первой сортировки новостей";
$MESS ['T_IBLOCK_DESC_IBORD2'] = "Поле для второй сортировки новостей";
$MESS ['T_IBLOCK_DESC_IBBY2'] = "Направление для второй сортировки новостей";
$MESS ['T_IBLOCK_DESC_LIST_ID'] = "Код информационного блока";
$MESS ['T_IBLOCK_DESC_LIST_TYPE'] = "Тип информационного блока";
$MESS ['T_IBLOCK_DESC_LIST_CONT'] = "Количество новостей на странице";
$MESS ['T_IBLOCK_DESC_ACTIVE_DATE_FORMAT'] = "Формат показа даты";
$MESS ['CP_BNL_FIELD_CODE'] = "Поля";
$MESS ['CP_BNL_CACHE_GROUPS'] = "Учитывать права доступа";
?>