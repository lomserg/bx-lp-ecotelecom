<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = array(
    "NAME" => "Список TV",
    "DESCRIPTION" => "Вывод списка телевизоров с свойствами",
    "PATH" => array(
        "ID" => "custom",
        "NAME" => "Мои компоненты"
    )
);
?>