<?
$MESS ['SLIDER_HL_NAME'] = "Слайдер из HL";
$MESS ['SLIDER_HL_DESCRIPTION'] = "Слайдер выводит информацию из HL";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Статьи и новости";
?>