<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = [
    "NAME" => "Детальный тариф",
    "DESCRIPTION" => "Выводит полную информацию по выбранному тарифу",
    "PATH" => [
        "ID" => "mycompany",
        "NAME" => "Мои компоненты"
    ],
];