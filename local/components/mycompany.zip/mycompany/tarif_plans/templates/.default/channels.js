

document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("channelsModal");
    const channelsList = document.getElementById("channelsList");
    const closeBtn = document.querySelector(".modal-close-bitix");

    document.querySelectorAll(".tarif__channels").forEach(item => {
        item.addEventListener("click", () => {
            console.log('click');
            const packageId = item.dataset.package;
            if (!packageId) return;

            fetch(`/local/channels/${packageId}.json`)
                .then(res => res.json())
                .then(channels => {
                    channelsList.innerHTML = "";
                    channels.forEach(ch => {
                        const li = document.createElement("li");
                        li.textContent = ch;
                        channelsList.appendChild(li);
                    });
                    console.log(channelsList);
                    modal.style.display = "flex";
                    document.body.classList.add("modal-open"); // блокируем скролл фона
                })
                .catch(err => {
                    console.error("Ошибка загрузки каналов", err);
                    channelsList.innerHTML = "<li>Не удалось загрузить список каналов</li>";
                    modal.style.display = "flex";
                    document.body.classList.add("modal-open"); // блокируем скролл фона
                });
        }); // <-- закрыта функция addEventListener
    }); // <-- закрыт forEach

    const closeModal = () => {
        modal.style.display = "none";
        document.body.classList.remove("modal-open"); // разблокируем скролл
    };

    closeBtn.addEventListener("click", closeModal);
    window.addEventListener("click", e => {
        if (e.target === modal) closeModal();
    });
});
