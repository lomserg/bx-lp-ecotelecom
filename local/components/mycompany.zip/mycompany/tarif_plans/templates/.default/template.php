<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<?php
use Bitrix\Main\Page\Asset;
Asset::getInstance()->addJs($templateFolder . "/channels.js");
?>
<?php //foreach($arResult["TARIFS"] as $tarif): ?>
<!--    <div class="swiper-slide tarif-option">-->
<!--        <div class="tarif-slider-description">-->
<!--            --><?php //if($tarif['promo']) : ?>
<!--                <div class="tarif-promo">Акция</div>-->
<!--            --><?php //endif; ?>
<!--            -->
<!--            <p class="tarif-name">--><?php //= $tarif["name"] ?><!--</p>-->
<!---->
<!---->
<!---->
<!--            <div class="tarif-param">-->
<!--                <p class="tarif-speed">--><?php //= $tarif["speed"] ?><!-- Мбит/c</p>-->
<!--                <div class="tarif channels-item --><?php //= $tarif['tv'] ? '' : 'ntv_channels' ?><!--">-->
<!--                    <a class="channels_link link trigger" href="#channels">-->
<!--                        --><?php //= $tarif["channels"] ?><!-- ТВ-каналов-->
<!--                    </a>-->
<!--                    --><?php //if(!$tarif['tv']): ?>
<!--                        <p style="color: black; font-size: 12px;">НТВ-ПЛЮС ТВ в подарок 🎁</p>-->
<!--                    --><?php //endif; ?>
<!--                </div>-->
<!--                --><?php //if($tarif['tv'] && !empty($tarif["movie"])): ?>
<!--                    <p class="tarif-movie" id="video2">--><?php //= $tarif["movie"] ?><!--</p>-->
<!--                --><?php //elseif($tarif['tv']): ?>
<!--                    <p class="tarif-movie" id="video2">-</p>-->
<!--                --><?php //endif; ?>
<!--            </div>-->
<!---->
<!--            <div class="tarif-options-description">-->
<!--                <ul class="tarif-options-list">-->
<!--
             </ul>-->
<!--            </div>-->
<!--            --><?php //if($tarif['promo'] && $tarif['price2']): ?>
<!--              <p class="tarif-price">-->
<!--                  --><?php //= $tarif['price2'] ?><!-- <span style="font-size: 0.75rem">₽/мес</span>-->
<!--                <span class="tarif-price-old">--><?php //= $tarif["price"] ?>
<!--                    <span style="font-size: 0.75rem">₽/мес</span></span>-->
<!--              </p>-->
<!--            --><?php //else: ?>
<!--              <p class="tarif-price">--><?php //= $tarif["price"] ?><!--<span style="font-size: 0.75rem">₽/мес</span></p>-->
<!--            --><?php //endif; ?>
<!--            --><?php //$utm = $_SERVER['QUERY_STRING'] ? '&' . $_SERVER['QUERY_STRING'] : ''; ?>
<!--            <a href="tarif.php?id=--><?php //= $tarif["id"] . $utm ?><!--" class="choose-btn">Выбрать</a>-->
<!--        </div>-->
<!--    </div>-->
<?php //endforeach; ?>
<h2 id="tarif_block" class="section-title fs-600">Выберите свой тариф</h2>
<div class="tab-box">
  <button class="tab_btn active" data-category="internet-tv">Интернет и ТВ</button>
  <button class="tab_btn" data-category="internet">Интернет</button>


</div>
<div class="tarifs-slider-container">
  <div class="swiper tarifs-slider-internet">
    <div class="swiper-wrapper">
<?php foreach($arResult["TARIFS"] as $tarif): ?>
  <div data-category="<?= $tarif["category"]; ?>" class="tarif-item swiper-slide">
    <h3 class="tarif-title"><?= $tarif["name"] ?></h3>
    <p class="tarif__description"><?= $tarif["description"] ?></p>
    <ul class="tarif__features">
      <li class="tarif__params"><?= $tarif["speed"] ?>&nbsp;<span>Мбит/сек</span></li>
      <li class="tarif__params tarif__channels"
          data-package="<?= $tarif["dataPackage"] ?>">
          <?= $tarif["channels"] ?>&nbsp;<span>ТВ-каналов</span>
      </li>
      <li class="tarif__params">
        1 из 3&nbsp;<span>онлайн-кинотаеатров</span>
      </li>
    </ul>
    <p class="tarif__price"><?= $tarif["price"] ?> <span>₽/мес</span></p>
    <button class="tarif-button tarif__btn-green">ПОДКЛЮЧИТЬ</button>
  </div>
<?php endforeach; ?>

    </div>

    <!-- Пагинация внутри слайдера -->
    <div class="swiper-pagination"></div>
  </div>

  <!-- Кнопки навигации ВНЕ слайдера -->
  <div class="swiper-button-prev tarif-custom-prev">
  </div>
  <div class="swiper-button-next tarif-custom-next">
  </div>
</div>
<div id="channelsModal" class="modal-bitix" style="display:none;">
  <div class="modal-content-bitix">
    <span class="modal-close-bitix">&times;</span>
    <h3>Список каналов</h3>
    <ul id="channelsList"></ul>
  </div>
</div>

