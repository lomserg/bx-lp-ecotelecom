<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

return [
    "NAME" => "Тарифы Экотелеком",
    "DESCRIPTION" => "Выводит список тарифов",
    "PATH" => [
        "ID" => "my_custom_section",
        "NAME" => "Мои компоненты",
    ],
];