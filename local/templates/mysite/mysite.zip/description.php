<?
$arTemplate = array (
  'NAME' => 'mysite',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>