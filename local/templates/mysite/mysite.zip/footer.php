</main><footer class="footer">
  <div class="footer-main">
    <img src="./img/Group_81.svg" alt="" class="footer-logo" />
    <p class="footer-text fs-100">
      «Экотелеком» — провайдер в Москве и Московской области
    </p>
    <p class="footer-fineprint fs-100">
      Продолжая использовать наш сайт, вы даете согласие на обработку файлов
      Cookies и других пользовательских данных
    </p>
    <p class="footer-fineprint fs-100">  <p>© <?=date("Y")?> Экотелеком</p></p>
  </div>
  <ul class="social-list">
    <li class="social-item">
      <a href="https://vk.com/ecotelecom_msk" class="social-link"><i class="fab fa-vk"></i></a>
    </li>
    <!--   <li class="social-item"><a href="https://www.facebook.com/ecotelecom" class="social-link"><i
                        class="fab fa-facebook-square"></i></a></li>
            <li class="social-item"><a href="https://www.instagram.com/ecotelecom_official/" class="social-link"><i
                        class="fab fa-instagram"></i></a></li>-->
  </ul>
</footer>

</body>
</html>
