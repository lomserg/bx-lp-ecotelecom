<h1 class="hero__title">Наш с тобой секрет</h1>
<h3 class="hero__title-second">ИНТЕРНЕТ по выгодным ценам</h3>