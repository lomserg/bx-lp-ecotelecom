function initSwiperIfReady(container) {
  // ждем, пока появятся хотя бы один слайд
  if (container.querySelectorAll('.swiper-slide').length === 0) {
    setTimeout(() => initSwiperIfReady(container), 50);
    return;
  }

  try {
    const swiper = new Swiper(container, {
      loop: false,
      grabCursor: true,
      spaceBetween: 20,
      // observer: true,
      // observeParents: true,
      pagination: {
        el: container.querySelector('.swiper-pagination'),
        clickable: true
      },
      navigation: {
        nextEl: '.tarif-custom-next',
        prevEl: '.tarif-custom-prev',
      },
      breakpoints: {
        0: { slidesPerView: 1.15 },
        550: { slidesPerView: 1.3 },
        768: { slidesPerView: 2.6 },
        991: { slidesPerView: 3 }
      }
    });
    
    console.log(`Swiper инициализирован для: ${container.className}`);
    return swiper;
  } catch (error) {
    console.error('Ошибка инициализации Swiper:', error);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  console.log('DOM загружен, инициализирую слайдеры...');
  
  const sliders = document.querySelectorAll('.tarifs__section .swiper');
  console.log(`Найдено слайдеров: ${sliders.length}`);
  
  sliders.forEach((container, index) => {
    console.log(`Инициализирую слайдер ${index + 1}:`, container.className);
    initSwiperIfReady(container);
  });
});